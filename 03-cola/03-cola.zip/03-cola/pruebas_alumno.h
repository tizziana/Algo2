#include "cola.h"
#include "testing.h"
#include <stddef.h>
#include <stdio.h>

void pruebas_cola_alumno() {

	printf("Inicio de pruebas con la cola:\n");
}