#include "cola.h"
#include "testing.h"
#include <stddef.h>
#include <stdio.h>

void pruebas_alumno() {

	printf("Inicio de pruebas con la pila1:\n");
}